clear all;clc; 
syms x y
f = abs(x) + 2*abs(y)
fsurf(f) 
xlabel('x') 
ylabel('y') 
title('Do thi ham so') 
grid on