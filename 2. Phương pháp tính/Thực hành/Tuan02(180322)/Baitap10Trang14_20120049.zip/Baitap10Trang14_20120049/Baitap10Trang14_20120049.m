clear all; clc;
format long;

KiemTra(438,425,15)
KiemTra(15659,15586,123)