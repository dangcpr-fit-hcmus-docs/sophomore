clear all; clc;
p_e1 = 0.9857
p_a1 = 0.9768
aEp1 = abs(p_e1-p_a1)
rEp1 = abs((p_e1-p_a1)/p_e1)

p_e2 = 421
p_a2 = 397
aEp2 = abs(p_e2-p_a2)
rEp2 = abs((p_e2-p_a2)/p_e2)

p_e3 = 1102
p_a3 = 1113
aEp3 = abs(p_e3-p_a3)
rEp3 = abs((p_e3-p_a3)/p_e3)

p_e4 = 2.5743
p_a4 = 2.6381
aEp = abs(p_e4-p_a4)
rEp = abs((p_e4-p_a4)/p_e4)