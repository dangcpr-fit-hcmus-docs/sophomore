clear all; clc;
format long

LamTron(pi,2)
ChatCut(pi,2)


LamTron(exp(1),3)
ChatCut(exp(1),3)

LamTron(log(2),4)
ChatCut(log(2),4)

LamTron(sqrt(2),5)
ChatCut(sqrt(2),5)


