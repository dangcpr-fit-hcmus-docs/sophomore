clear all; clc;

xx1=[0.9;1;1.1;1.2;1.3];
yy1=[0.7833;0.8415;0.8912;0.9320;0.9636];
df1=0.5403;

Saiphan(xx1,yy1,df1)
BaDiemGiua(xx1,yy1,df1)
NamDiemGiua(xx1,yy1,df1)