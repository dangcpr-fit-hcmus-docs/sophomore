clear all;clc;

xx=[2;4;7;8];
yy=[2.2;1.8;2.7;3.1];
x1=3;x2=7.5;

Spline(xx,yy,x1,x2)
BPNNThang(xx,yy,4)
BPNNCong(xx,yy,4)