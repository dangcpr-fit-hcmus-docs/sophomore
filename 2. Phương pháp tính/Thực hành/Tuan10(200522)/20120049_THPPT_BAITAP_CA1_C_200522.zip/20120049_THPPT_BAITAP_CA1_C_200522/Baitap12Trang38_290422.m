clear all;clc;

xx1=[1;2;3;4];
yy1=[-1.5;0.1;2.3;5.1];
xc1=4;

xx2=[1;2;3;4];
yy2=[3*1+1.5*sin(1)-3.5*cos(1);3*2+1.5*sin(2)-3.5*cos(2);3*3+1.5*sin(3)-3.5*cos(3);3*4+1.5*sin(4)-3.5*cos(4)];
xc2=4;

% BPNNBac2(xx1,yy1,xc1)
BPNNSin(xx2,yy2,xc2)