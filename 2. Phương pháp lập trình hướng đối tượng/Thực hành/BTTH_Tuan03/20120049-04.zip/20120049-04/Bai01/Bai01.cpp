#include <iostream>
#include "Point.h"
using namespace std;
int main()
{
	Point a;
	cout << a.ToString() << endl;
	Point b;
	cout << endl << b.ToString();
}