﻿#include <iostream>
#include "Header.h"
int main()
{
	ListStudent list;
	list.input();
	list.listGraduate();
}